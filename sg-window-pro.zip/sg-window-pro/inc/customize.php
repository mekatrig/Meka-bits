<?php
/* Include extra 'sgwindowpro' to customizer */
add_action( 'customize_register', 'sgwindowpro_create_section_extra_layout', 20 );
function sgwindowpro_create_section_extra_layout( $wp_customize ) {

	if ( ! function_exists ( 'sgwindow_get_theme_mod' ) )
		return;
		
	$defaults = sgwindow_get_defaults();
	
	$priority = 1;
	$section_priority = 10;

//site width range + text	
	$wp_customize->add_setting( 'width_site_range', array(
		'type'			 => 'empty',
		'default'        => sgwindow_get_theme_mod('width_site'),
		'capability'     => 'edit_theme_options',
		'transport'		 => 'postMessage',
		'sanitize_callback' => 'absint'
	) );

	$wp_customize->add_control( 'width_site_range', array(
		'label'      => __( '(px)', 'sgwindowpro' ),
		'section'    => 'size',
		'settings'   => 'width_site_range',
		'type'       => 'range',
		'input_attrs' => array(
			'min'   => 960,
			'max'   => 2200,
			'step'  => 1,),
		'priority' => $priority++,
	));
	
	$wp_customize->add_setting( 'width_site', array(
		'type'			 => 'theme_mod',
		'default'        => $defaults['width_site'],
		'capability'     => 'edit_theme_options',
		'transport'		 => 'postMessage',
		'sanitize_callback' => 'sgwindow_sanitize_range_width'
	) );

	$wp_customize->add_control( 'width_site', array(
		'label'      => __( 'Width of the site', 'sgwindowpro' ),
		'section'    => 'size',
		'settings'   => 'width_site',
		'type'       => 'text',
		'priority'       => $priority++,
	) );
	
//content area width range + text
	$wp_customize->add_setting( 'width_main_wrapper_range', array(
		'type'			 => 'empty',
		'default'        => sgwindow_get_theme_mod('width_main_wrapper'),
		'capability'     => 'edit_theme_options',
		'transport'		 => 'postMessage',
		'sanitize_callback' => 'absint'
	) );

	$wp_customize->add_control( 'width_main_wrapper_range', array(
		'label'      => __( '(px)', 'sgwindowpro' ),
		'section'    => 'size',
		'settings'   => 'width_main_wrapper_range',
		'type'       => 'range',
		'priority' => $priority++,
		'input_attrs' => array(
			'min'   => 600,
			'max'   => 2200,
			'step'  => 1,
	) ));
	
	$wp_customize->add_setting( 'width_main_wrapper', array(
		'type'			 => 'theme_mod',
		'default'        => $defaults['width_main_wrapper'],
		'capability'     => 'edit_theme_options',
		'transport'		 => 'postMessage',
		'sanitize_callback' => 'sgwindow_sanitize_range_content'
	) );

	$wp_customize->add_control( 'width_main_wrapper', array(
		'label'      => __( 'Width of the content area (including columns)', 'sgwindowpro' ),
		'section'    => 'size',
		'settings'   => 'width_main_wrapper',
		'type'       => 'text',
		'priority'       => $priority++,
	) );
	
	$wp_customize->add_setting( 'content_style', array(
		'type'			 => 'theme_mod',
		'default'        => $defaults['content_style'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'sgwindow_sanitize_header_style'
	) );

	$wp_customize->add_control( 'content_style', array(
		'label'   => __( 'Content style', 'sgwindowpro' ),
		'section' => 'size',
		'settings'   => 'content_style',
		'type'       => 'select',
		'priority'   => $priority++,
		'choices'	 => array ('boxed' => __('Boxed', 'sgwindowpro'),
								'full' => __('Full Width', 'sgwindowpro'))
	) );	
	
	$wp_customize->add_setting( 'site_style', array(
		'type'			 => 'theme_mod',
		'default'        => $defaults['site_style'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'sgwindow_sanitize_header_style'
	) );

	$wp_customize->add_control( 'site_style', array(
		'label'   => __( 'Website style', 'sgwindowpro' ),
		'section' => 'size',
		'settings'   => 'site_style',
		'type'       => 'select',
		'priority'   => $priority++,
		'choices'	 => array ('boxed' => __('Boxed', 'sgwindowpro'),
								'full' => __('Full Width', 'sgwindowpro'))
	) );
	
//New section in customizer: Footer
	$wp_customize->add_section( 'footer_text', array(
		'title'          => __( 'Footer text', 'sgwindowpro' ),
		'priority'       => $section_priority++,
		'panel'  => 'other',
	) );
	
//New setting in Footer section: 
	$wp_customize->add_setting( 'footer_text', array(
		'default'        => $defaults['footer_text'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'sgwindow_sanitize_kses'
	) );
	$wp_customize->add_control( 'footer_text', array(
		'label'      => __('Text', 'sgwindowpro'),
		'section'    => 'footer_text',
		'settings'   => 'footer_text',
		'priority'   => '1',
	));
	
//New section in customizer: Parallax options
	$wp_customize->add_section( 'parallax', array(
		'title'          => __( 'Parallax Header', 'sgwindowpro' ),
		'priority'       => $section_priority++,
		'panel'  => 'other',
	) );
	
	$wp_customize->add_setting( 'is_parallax_header', array(
		'default'        => $defaults['is_parallax_header'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'sgwindow_sanitize_checkbox'
	) );

	$wp_customize->add_control( 'is_parallax_header', array(
		'label'      => __( 'Use header with parallax effect', 'sgwindowpro' ),
		'section'    => 'parallax',
		'settings'   => 'is_parallax_header',
		'type'       => 'checkbox',
		'priority'       => 40,
	) );
//New setting in Parallax section: 
	$wp_customize->add_setting( 'parallax_image_speed', array(
		'default'        => $defaults['parallax_image_speed'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'absint'
	) );
	$wp_customize->add_control( 'parallax_image_speed', array(
		'label'      => __('Speed (number between 10-100). This option increase size of image.', 'sgwindowpro'),
		'section'    => 'parallax',
		'settings'   => 'parallax_image_speed',
		'priority'   => '1',
	));
//New setting in Parallax section: 
	$wp_customize->add_setting( 'parallax_image_height', array(
		'default'        => $defaults['parallax_image_height'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'absint'
	) );
	$wp_customize->add_control( 'parallax_image_height', array(
		'label'      => __('Height of parallax section', 'sgwindowpro'),
		'section'    => 'parallax',
		'settings'   => 'parallax_image_height',
		'priority'   => '1',
	));
	
//New section in customizer: Parallax options
	$wp_customize->add_section( 'sticky_menu', array(
		'title'          => __( 'Sticky Menu', 'sgwindowpro' ),
		'priority'       => 100,
		'panel'  => 'other',
	) );
	
	$wp_customize->add_setting( 'is_sticky_first_menu', array(
		'default'        => $defaults['is_sticky_first_menu'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'sgwindow_sanitize_checkbox'
	) );

	$wp_customize->add_control( 'is_sticky_first_menu', array(
		'label'      => __( 'Keep First Menu on top of the screen while scrolling', 'sgwindowpro' ),
		'section'    => 'sticky_menu',
		'settings'   => 'is_sticky_first_menu',
		'type'       => 'checkbox',
		'priority'       => 1,
	) );
	
	$wp_customize->add_setting( 'is_sticky_second_menu', array(
		'default'        => $defaults['is_sticky_second_menu'],
		'capability'     => 'edit_theme_options',
		'sanitize_callback' => 'sgwindow_sanitize_checkbox'
	) );

	$wp_customize->add_control( 'is_sticky_second_menu', array(
		'label'      => __( 'Keep Second Menu on top of the screen while scrolling', 'sgwindowpro' ),
		'section'    => 'sticky_menu',
		'settings'   => 'is_sticky_second_menu',
		'type'       => 'checkbox',
		'priority'       => 1,
	) );
}

/**
 * Set defaults (new options)
 *
*/

function sgwindowpro_defaults( $defaults ) {

	if( ! isset( $defaults['site_style'] ) )
		$defaults['site_style'] = 'full';
	if( ! isset( $defaults['is_parallax_header'] ) )
		$defaults['site_style'] = '';
	if( ! isset( $defaults['parallax_image_speed'] ) )
		$defaults['parallax_image_speed'] = 30;
	if( ! isset( $defaults['parallax_image_height'] ) )
		$defaults['parallax_image_height'] = 400;	
	if( ! isset( $defaults['is_sticky_second_menu'] ) )
		$defaults['is_sticky_second_menu'] = '';	
	if( ! isset( $defaults['is_sticky_first_menu'] ) )
		$defaults['is_sticky_first_menu'] = '';

	return $defaults;

}
add_filter( 'sgwindow_option_defaults', 'sgwindowpro_defaults' );

/**
 * Add body classes
 *
*/

function sgwindowpro_body_class( $classes ) {

	if( 'boxed' == sgwindow_get_theme_mod( 'site_style' ) ){
		$classes[] = 'boxed-site';
	}

	return $classes;
}
add_filter( 'body_class', 'sgwindowpro_body_class' );

/**
 * Enqueue sticky menu script
 *
*/

function sgwindowpro_styles() {

	if ( '1' == sgwindow_get_theme_mod( 'is_sticky_first_menu' ) ) {
		wp_enqueue_script( 'sgwindow-sticky', plugin_dir_url( __FILE__ ) . 'js/sticky-1.js', array( 'jquery' ), '201531', true );
	} elseif ( '1' == sgwindow_get_theme_mod( 'is_sticky_second_menu' ) ) {
		wp_enqueue_script( 'sgwindow-sticky', plugin_dir_url( __FILE__ ) . 'js/sticky.js', array( 'jquery' ), '201531', true );
	}
	
}
add_action( 'wp_enqueue_scripts', 'sgwindowpro_styles', 100 );