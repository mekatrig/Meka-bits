<?php
/**
 * Class to create custom colors for every widget
 *
 * @since SG Window Pro 1.0.0
 */

class sgwindow_Widget_Colors_Class {

	private $js;

	function __construct() {
	
		$this->js = '';
		
		add_action( 'customize_register', array( $this, 'create_colors_controls' ), 21 );
		add_action( 'customize_controls_print_scripts', array( $this, 'print_customizer_js_colors') );

	}
	
	public function create_colors_controls( $wp_customize ) {
	
		$defaults = sgwindow_get_defaults();

		$sidebars_widgets = get_option('sidebars_widgets', array());
		
		if( ! isset( $sidebars_widgets ) )
			return;
		
		$wp_customize->add_panel( 'custom_widget_colors', array(
				'priority'       => 106,
				'title'          => __( 'Customize Widget Colors', 'sgwindowpro' ),
				'description'    => __( 'In this section you can change colors for each widget in the Top Sidebar.', 'sgwindowpro' ),
			) );
		
		$priority = 1;
		
		$sidebar_id =  'sidebar-top';
		
		/* check for per page sidebars */
		
		$page_sidebars = ( array )get_theme_mod( 'page_sidebars', null );
			
		foreach( $page_sidebars as $page_id ) {
		
			$sidebar_name = $sidebar_id . '-page_' . $page_id;
			$callback = create_function( '', 'return is_page( ' . $page_id . ' );' );
			
			if ( ! isset( $sidebars_widgets[ $sidebar_name ] ) )
					continue;
					
			$widgets = (array) $sidebars_widgets[ $sidebar_name ];
			
			$this->create_controls( $wp_customize, $widgets, $callback, $sidebar_name, $sidebar_name );

		}
			
		foreach( $defaults['defined_sidebars'] as $slug => $defined_sidebars ) {
			//is this type of sidebars in use
			if( '1' != get_theme_mod($slug, $defined_sidebars['use']) )
				continue;
				
			$callback = $defined_sidebars['callback'];

			$def = ( isset( $defined_sidebars[ $sidebar_id ]) ? $defined_sidebars[ $sidebar_id ] : '' );
			
			$sidebar = get_theme_mod( $sidebar_id . '_' . $slug, 'empty' );
			if( 'empty' == $sidebar )
				$sidebar = $def;
			
			/* active sidebar */
			if( '1' == $sidebar ) {

				/* create section in the customizer for each widget in sidebar-top-xxx sidebar */
				$sidebar_name = $sidebar_id . '-' . $slug;
				
				if ( ! isset( $sidebars_widgets[ $sidebar_name ] ) )
					continue;
					
				$widgets = (array) $sidebars_widgets[ $sidebar_name ];
				
				$this->create_controls( $wp_customize, $widgets, $callback, $sidebar_name, $defined_sidebars['title'], 100 );
			}
		}
	}
	/* Create section 'Widget Colors' in the Customizer */
	public function create_controls( $wp_customize, $widgets, $callback, $sidebar_name, $title, $priority = 1 ) {

		if ( ! function_exists ( $callback ) ) {
		//	return;
		}
		
		$ind = 0;
		$widget_ind = 0;
		
		foreach ( $widgets as $id => $widget ) {
				
			$theme_mod = $sidebar_name . '_widget["' . $widget_ind . '"]';
			
			$wp_customize->add_section( $theme_mod, array(
					'priority'       => $priority++,
					'title'          => __( 'Widget Number ', 'sgwindowpro' ) . ( $widget_ind + 1 ) . ' (' . $title . ')',
					'description'    => __( 'Customize colors for ', 'sgwindowpro' ) . $widget,
					'panel'  => 'custom_widget_colors',
				) );
				
			$type = 'is_active';
			//switch on custom colors
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_checkbox'
			) );

			$wp_customize->add_control( $theme_mod . '["' . $type . '"]', array(
				'label'      => __( 'Check mark to activate custom colors for this Widget', 'sgwindowpro' ),
				'section'    => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'type'       => 'checkbox',
				'priority'       => $ind++,
				'active_callback' => $callback,
			) );	


			/* custom colors for the background, text, link, link hover, background opacity */
			$type = 'back';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '#fff',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_hex_color'
			) );
				
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $theme_mod . '["' . $type . '"]', array(
				'label'   => __( 'Background', 'sgwindowpro' ),
				'section' => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'priority' =>  $ind++,
				'active_callback' => $callback,
			) ) );
			
			
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ')", window.parent.frames[0].document ).css( "background-color", to_rgba(to, GetControlVal' . "('" . $theme_mod . '["' . 'opacity' . '"]' . "'" . ')));
					} );
				} );';
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . 'opacity' . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ')", window.parent.frames[0].document ).css( "background-color", to_rgba( GetControlVal' . "('" . $theme_mod . '["' . $type . '"]' . "'" . '), to));
					} );
				} );';
				
			$type = 'opacity';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '1',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_opacity'
			) );
	
			
			$wp_customize->add_control( $theme_mod . '["' . $type . '"]', array(
				'label'      => __( 'Opacity', 'sgwindowpro' ),
				'section'    => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'type'       => 'select',
				'priority'   => $ind++,
				'choices'	 => array ('0' => '0',
									   '0.1' => '0.1', 
									   '0.2' => '0.2', 
									   '0.3' => '0.3', 
									   '0.4' => '0.4', 
									   '0.5' => '0.5',
									   '0.6' => '0.6', 
									   '0.7' => '0.7',
									   '0.8' => '0.8',
									   '0.9' =>  '0.9',
									   '1' => '1'),
				'active_callback' => $callback,
			) );

				
			$type = 'opacity_range';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'type'			 => 'empty',
				'default'        => 10*get_theme_mod( $theme_mod . '["' . 'opacity' . '"]', '1'),
				'capability'     => 'edit_theme_options',
				'transport'		 => 'postMessage',
				'sanitize_callback' => 'absint'
			) );

			$wp_customize->add_control( $theme_mod . '["' . $type . '"]', array(
				'label'      => '',
				'section'    => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'type'       => 'range',
				'input_attrs' => array(
					'min'   => 1,
					'max'   => 10,
					'step'  => 1,),
					'priority' =>  $ind++,
				'active_callback' => $callback,
			) );
			
			// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
							SetControlVal(' . "'" . $theme_mod . '["' . 'opacity' . '"]' . "'" . ' , parseInt( to )/10);
					} );
				} );';
						
			/* widget title */
			
			$type = 'title';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '#fff',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_hex_color'
			) );
				
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $theme_mod . '["' . $type . '"]', array(
				'label'   => __( 'Title Background', 'sgwindowpro' ),
				'section' => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'priority' =>  $ind++,
				'active_callback' => $callback,
			) ) );
			
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ') .widget-title", window.parent.frames[0].document ).css( "background-color", to_rgba(to, GetControlVal' . "('" . $theme_mod . '["' . 'opacity' . '"]' . "'" . ')));
					} );
				} );';
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . 'title_opacity' . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ') .widget-title", window.parent.frames[0].document ).css( "background-color", to_rgba( GetControlVal' . "('" . $theme_mod . '["' . $type . '"]' . "'" . '), to));
					} );
				} );';
				
			$type = 'title_opacity';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '1',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_opacity'
			) );
			
			$wp_customize->add_control( $theme_mod . '["' . $type . '"]', array(
				'label'      => __( 'Opacity', 'sgwindowpro' ),
				'section'    => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'type'       => 'select',
				'priority'   => $ind++,
				'choices'	 => array ('0' => '0',
									   '0.1' => '0.1', 
									   '0.2' => '0.2', 
									   '0.3' => '0.3', 
									   '0.4' => '0.4', 
									   '0.5' => '0.5',
									   '0.6' => '0.6', 
									   '0.7' => '0.7',
									   '0.8' => '0.8',
									   '0.9' =>  '0.9',
									   '1' => '1'),
				'active_callback' => $callback,
			) );
				
			$type = 'title_opacity_range';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'type'			 => 'empty',
				'default'        => 10*get_theme_mod( $theme_mod . '["' . 'title_opacity' . '"]', '1'),
				'capability'     => 'edit_theme_options',
				'transport'		 => 'postMessage',
				'sanitize_callback' => 'absint'
			) );

			$wp_customize->add_control( $theme_mod . '["' . $type . '"]', array(
				'label'      => '',
				'section'    => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'type'       => 'range',
				'input_attrs' => array(
					'min'   => 1,
					'max'   => 10,
					'step'  => 1,),
					'priority' =>  $ind++,
				'active_callback' => $callback,
			) );
			
			// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
							SetControlVal(' . "'" . $theme_mod . '["' . 'title_opacity' . '"]' . "'" . ' , parseInt( to )/10);
					} );
				} );';
				
			/* text */
			$type = 'title_text';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '#666',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_hex_color'
			) );
				
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $theme_mod . '["' . $type . '"]', array(
				'label'   => __( 'Title Text', 'sgwindowpro' ),
				'section' => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'priority' =>  $ind++,
				'active_callback' => $callback,
			) ) );
			
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ') .widget-title", window.parent.frames[0].document ).css( "color", to );
					} );
				} );';
			
			/* text */
			$type = 'text';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '#666',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_hex_color'
			) );
				
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $theme_mod . '["' . $type . '"]', array(
				'label'   => __( 'Text', 'sgwindowpro' ),
				'section' => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'priority' =>  $ind++,
				'active_callback' => $callback,
			) ) );
			
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ')", window.parent.frames[0].document ).css( "color", to );
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ') .content-container", window.parent.frames[0].document ).css( "color", to );
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ') .content-container .entry-title", window.parent.frames[0].document ).css( "color", to );
					} );
				} );';
				
			/* link */
			$type = 'link';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '#1e73be',
				'transport'		 => 'postMessage',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_hex_color'
			) );
				
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $theme_mod . '["' . $type . '"]', array(
				'label'   => __( 'Link', 'sgwindowpro' ),
				'section' => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'priority' =>  $ind++,
				'active_callback' => $callback,
			) ) );
			
		// create js functions for controls	
			$this->js .= "wp.customize( '" . $theme_mod . '["' . $type . '"]' . "'" . ', function( value ) {
					value.bind( function( to ) {
						$( ".sidebar-top-full .widget:nth-child(' . ( $widget_ind + 1 ) . ') a", window.parent.frames[0].document ).css( "color", to );
					} );
				} );';
			/* link hover */
			$type = 'hover';
			$wp_customize->add_setting( $theme_mod . '["' . $type . '"]', array(
				'default'        => '#eee',
				'capability'     => 'edit_theme_options',
				'sanitize_callback' => 'sgwindow_sanitize_hex_color'
			) );
				
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $theme_mod . '["' . $type . '"]', array(
				'label'   => __( 'Hover', 'sgwindowpro' ),
				'section' => $theme_mod,
				'settings'   => $theme_mod . '["' . $type . '"]',
				'priority' =>  $ind++,
				'active_callback' => $callback,
			) ) );
			
			$widget_ind++;
			
		}
	}
		
	/* Print postMessage js for color controls */
	public function print_customizer_js_colors() {
		?>
		<script type="text/javascript">
			jQuery( document ).ready(function( $ ) {
				var api = parent.wp.customize;
				function to_rgba( color, opacity) {
					var rgbaCol = 'rgba(' + parseInt(color.slice(-6,-4),16)
					+ ',' + parseInt(color.slice(-4,-2),16)
					+ ',' + parseInt(color.slice(-2),16)
					+',' + opacity+')';
					return rgbaCol;
				};
				function GetControlVal( name ) {
					var control = api.control( name ); 
					var rez = '';
					if( control ){
						rez = control.setting.get();
					}
					return rez;
				};
				function SetControlVal(name, newVal) {
					var control = api.control(name); 
					if( control ){
						control.setting.set( newVal );
					}
					return;
				}
		<?php
				echo $this->js;
		?>
			});
		</script>
	<?php
	}
}
/**
 * Print color css for sidebar.
 *
 * $sidebar_name string sidebar id
 *
 * @since SG Window 1.0.0
*/
function sgwindow_echo_colors( $sidebar_name ) {
	
	$theme_mod_name = $sidebar_name . '_widget';
	$theme_mod = ( array ) get_theme_mod( $theme_mod_name, '' );
	
	foreach ( $theme_mod as $id => $widget ) {
	
		$widget = ( array ) $widget;
		$id = str_replace('"', '', $id);
		
		if ( ! array_key_exists ( '"is_active"', $widget ) )
			continue;
			
		if ( '1' != $widget['"is_active"'] )
			continue;
		
		$op = 1;
		if ( array_key_exists ( '"opacity"', $widget ) ) {
			$op	= $widget['"opacity"'];
		}
		
		$op_title = 1;
		if ( array_key_exists ( '"title_opacity"', $widget ) ) {
			$op_title = $widget['"title_opacity"'];
		}
	
		if ( array_key_exists ( '"back"', $widget ) ) : ?>
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) {
				background-color: <?php echo esc_attr( sgwindow_hex_to_rgba( $widget['"back"'], $op ) ); ?>;
			}
		<?php
		endif;
		if ( array_key_exists ( '"text"', $widget ) ) : ?>
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>),
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) .content-container .entry-title,
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) .content-container {
				color: <?php echo esc_attr( $widget['"text"'] ); ?>;
			}
		<?php
		endif;
		if ( array_key_exists ( '"link"', $widget ) ) : ?>
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) a,
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) a .content-container {
				color: <?php echo esc_attr( $widget['"link"'] ); ?>;
			}
		<?php
		endif;
		if ( array_key_exists ( '"hover"', $widget ) ) : ?>
			#sidebat-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) a:hover,
			#sidebat-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) a:hover .content-container {
				color: <?php echo esc_attr( $widget['"hover"'] ); ?>;
			}
		<?php
		endif;
		if ( array_key_exists ( '"title"', $widget ) ) : ?>
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) .widgettitle,
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) .widget-title {
				background: <?php echo esc_attr( sgwindow_hex_to_rgba( $widget['"title"'], $op_title ) ); ?>;
			}
		<?php
		endif;
		if ( array_key_exists ( '"title_text"', $widget ) ) : ?>
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) .widgettitle,
			#sidebar-1 .widget:nth-child(<?php echo esc_attr( intval( $id ) + 1 ); ?>) .widget-title {
				color: <?php echo esc_attr( $widget['"title_text"'] ); ?>;
			}
		<?php
		endif;
	}
}
 /**
 * Add custom styles to the header.
 *
 * @since SG Window Pro 1.0.0
*/
function sgwindow_hook_css_widgets() {
/* Set custom colors for widgets */
?>
	<style type="text/css"> 	
<?php
	
	$sidebar_id = 'sidebar-top';
	$curr_slug = sgwindow_get_sidebar_slug();
	sgwindow_echo_colors( $sidebar_id . '-' . $curr_slug );
		
?>
	</style>
<?php
}
add_action('wp_head', 'sgwindow_hook_css_widgets');