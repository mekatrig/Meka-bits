<?php
 /**
 * Add extra color options
 *
 * @since SG Window Pro 1.0.0
*/

add_action( 'after_setup_theme', 'sgwindow_pro_setup', 100 );
function sgwindow_pro_setup() {
	if ( ! function_exists ( 'sgwindow_get_theme_mod' ) )
		return;

	$defaults = sgwindow_get_defaults();
	
	global $sgwindow_colors_class;
	
	if ( ! defined ( 'SGWINDOWCHILD' ) ) {
	 	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
		
		/* colors */
		
		$i = 'site_name_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#25c1f9', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#81d742', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#25c1f9', 0.6);

			
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');

		
	//section menu 
		$section_id = 'menu_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('First Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);
		
		$i = 'menu1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);

		$i = 'menu1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#50912d');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		
		
		
		$i = 'menu1_top_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#50912d');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');

		
		$i = 'menu1_hover_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#175e1b', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.5);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#e0dd1f');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#127a14');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section third menu 
		$section_id = 'menu_3_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu3_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#175e1b', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.5);
		
		$i = 'menu3_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#e0dd1f');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		$i = 'menu3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#127a14');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu3_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#81d742', 0.3);
		$sgwindow_colors_class->set_color($i, 1, '#eeee22', 0.6);
		$sgwindow_colors_class->set_color($i, 2, '#81d742', 0.3);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 1, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 1, '#a5a5a5');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 0.9);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 0.9);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 1);
		$sgwindow_colors_class->set_color($i, 1, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.4);	
		$sgwindow_colors_class->set_color($i, 1, '#eeeeee', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f2e4d2');		
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#301272');			
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#efefef');
		$sgwindow_colors_class->set_color($i, 1, '#666666');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');
		
		$i = 'sidebar1_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#bfbfbf');
		$sgwindow_colors_class->set_color($i, 1, '#bfbfbf');
		$sgwindow_colors_class->set_color($i, 2, '#bfbfbf');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.4);	
		$sgwindow_colors_class->set_color($i, 1, '#eeeeee', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	

		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#c7e5e1');	
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');	
		$sgwindow_colors_class->set_color($i, 2, '#301272');	

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#efefef');
		$sgwindow_colors_class->set_color($i, 1, '#666666');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');
		
		$i = 'sidebar4_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#bfbfbf');
		$sgwindow_colors_class->set_color($i, 1, '#bfbfbf');
		$sgwindow_colors_class->set_color($i, 2, '#bfbfbf');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.2);	
		$sgwindow_colors_class->set_color($i, 1, '#35d620', 0.2);	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.2);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#81d742');	
		$sgwindow_colors_class->set_color($i, 1, '#e2e547');	
		$sgwindow_colors_class->set_color($i, 2, '#81d742');	
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc');
		$sgwindow_colors_class->set_color($i, 1, '#cccccc');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar3_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#eeeeee', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#eeeeee', 1);		
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#3dbf2b');	
		$sgwindow_colors_class->set_color($i, 1, '#175e1b');	
		$sgwindow_colors_class->set_color($i, 2, '#3dbf2b');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 1, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 2, '#aaaaaa');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#175e1b', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#777777');		
		$sgwindow_colors_class->set_color($i, 1, '#eeee22');
		$sgwindow_colors_class->set_color($i, 2, '#777777');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#f7f7f7');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'column_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#f7f7f7', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#7a7a7a');		
		$sgwindow_colors_class->set_color($i, 1, '#5b5b5b');
		$sgwindow_colors_class->set_color($i, 2, '#7a7a7a');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
		
//sidebar-widget
		$section_id = 'sidebar-widget';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Layout Builder', 'sgwindowpro'), __('Widget-sidebar colors', 'sgwindowpro'), $section_priority++);

		$i = 'layout_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ededed', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ededed', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ededed', 1);	
		
		$i = 'layout_content';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.9);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);	
		
		$i = 'layout_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Border Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);	
		
		$i = 'layout_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#81d742');	
		$sgwindow_colors_class->set_color($i, 1, '#81d742');	
		$sgwindow_colors_class->set_color($i, 2, '#81d742');	
		
		$i = 'layout_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#666666');	
		$sgwindow_colors_class->set_color($i, 1, '#666666');	
		$sgwindow_colors_class->set_color($i, 2, '#666666');	
		
		$i = 'layout_title';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'layout_title_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Title Text', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');
	}
	elseif( 'SGCircus' == SGWINDOWCHILD ) {
	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
	
		$i = 'site_name_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#25c1f9', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#81d742', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#25c1f9', 0.6);

			
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');

		
	//section menu 
		$section_id = 'menu_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('First Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);
		
		$i = 'menu1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);

		$i = 'menu1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#50912d');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		
		
		
		$i = 'menu1_top_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#50912d');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');

		
		$i = 'menu1_hover_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#175e1b', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.5);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#e0dd1f');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#127a14');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section third menu 
		$section_id = 'menu_3_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu3_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#175e1b', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.5);
		
		$i = 'menu3_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#e0dd1f');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		$i = 'menu3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#127a14');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu3_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#292272', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#eeee22', 0.6);
		$sgwindow_colors_class->set_color($i, 2, '#81d742', 0.3);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f46a38');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f2f2f2');
		$sgwindow_colors_class->set_color($i, 1, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#31e820');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 1, '#a5a5a5');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 0.9);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 0.9);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 1);
		$sgwindow_colors_class->set_color($i, 1, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#eeeeee', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#eeeeee', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#301272');			
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#81d742');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#828282');
		$sgwindow_colors_class->set_color($i, 1, '#666');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');
		
		$i = 'sidebar1_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#969696');
		$sgwindow_colors_class->set_color($i, 1, '#bfbfbf');
		$sgwindow_colors_class->set_color($i, 2, '#bfbfbf');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.9);	
		$sgwindow_colors_class->set_color($i, 1, '#eeeeee', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	

		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');	
		$sgwindow_colors_class->set_color($i, 2, '#301272');	

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#81d742');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#7a7a7a');
		$sgwindow_colors_class->set_color($i, 1, '#666666');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');
		
		$i = 'sidebar4_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#7a7a7a');
		$sgwindow_colors_class->set_color($i, 1, '#bfbfbf');
		$sgwindow_colors_class->set_color($i, 2, '#bfbfbf');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#0b0419', 0.8);	
		$sgwindow_colors_class->set_color($i, 1, '#35d620', 0.2);	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.2);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 1, '#e2e547');	
		$sgwindow_colors_class->set_color($i, 2, '#81d742');	
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#81d742');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f2f2f2');
		$sgwindow_colors_class->set_color($i, 1, '#cccccc');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar3_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#000000', 1);
		$sgwindow_colors_class->set_color($i, 2, '#137c96', 0.9);		
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#81d742');
		$sgwindow_colors_class->set_color($i, 1, '#81d742');
		$sgwindow_colors_class->set_color($i, 2, '#81d742');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 1);
		$sgwindow_colors_class->set_color($i, 1, '#175e1b', 1);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 1);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#f7f7f7', 0);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);
		
		$i = 'column_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.9);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#353535');		
		$sgwindow_colors_class->set_color($i, 1, '#5b5b5b');
		$sgwindow_colors_class->set_color($i, 2, '#7a7a7a');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#dbdbdb', 1);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
	}
	elseif( 'SGSimple' == SGWINDOWCHILD ) {
	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
	
		$i = 'site_name_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.4);
		$sgwindow_colors_class->set_color($i, 1, '#0e510b', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.4);

			
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');

		
	//section menu 
		$section_id = 'menu_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('First Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);
		
		$i = 'menu1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);

		$i = 'menu1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');		
		
		
		$i = 'menu1_top_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');

		
		$i = 'menu1_hover_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');		

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section third menu 
		$section_id = 'menu_3_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu3_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'menu3_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');		

		$i = 'menu3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');
		
		$i = 'menu3_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#292272', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#292272', 0.6);
		$sgwindow_colors_class->set_color($i, 2, '#292272', 0.6);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f46a38');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f2f2f2');
		$sgwindow_colors_class->set_color($i, 1, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 1, '#a5a5a5');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 0.9);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 1);
		$sgwindow_colors_class->set_color($i, 1, '#1e73be', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);	
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#b5b5b5');
		$sgwindow_colors_class->set_color($i, 2, '#b5b5b5');			
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dbdbdb');
		$sgwindow_colors_class->set_color($i, 1, '#dbdbdb');
		$sgwindow_colors_class->set_color($i, 2, '#dbdbdb');
		
		$i = 'sidebar1_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);	
		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#b5b5b5');
		$sgwindow_colors_class->set_color($i, 2, '#b5b5b5');		

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dbdbdb');
		$sgwindow_colors_class->set_color($i, 1, '#dbdbdb');
		$sgwindow_colors_class->set_color($i, 2, '#dbdbdb');
		
		$i = 'sidebar4_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#afafaf', 0);	
		$sgwindow_colors_class->set_color($i, 1, '#35d620', 0);	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#a8a8a8');	
		$sgwindow_colors_class->set_color($i, 1, '#a8a8a8');	
		$sgwindow_colors_class->set_color($i, 2, '#a8a8a8');	
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dbdbdb');
		$sgwindow_colors_class->set_color($i, 1, '#dbdbdb');
		$sgwindow_colors_class->set_color($i, 2, '#dbdbdb');

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar3_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#0c2d4f', 0.6);	
		$sgwindow_colors_class->set_color($i, 1, '#0c2d4f', 0.6);
		$sgwindow_colors_class->set_color($i, 2, '#0c2d4f', 0.6);		
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#999999');
		$sgwindow_colors_class->set_color($i, 1, '#999999');
		$sgwindow_colors_class->set_color($i, 2, '#999999');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cecece', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#cecece', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#f7f7f7', 0);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);
		
		$i = 'column_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 0);
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#e0e4f9', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#e0e4f9', 0.9);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#060a3f');		
		$sgwindow_colors_class->set_color($i, 1, '#060a3f');
		$sgwindow_colors_class->set_color($i, 2, '#060a3f');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#dbdbdb', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 0);
		
	} elseif( 'SGGrid' == SGWINDOWCHILD ) {
	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
	
		$i = 'site_name_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#0e0d59', 0.8);
		$sgwindow_colors_class->set_color($i, 1, '#0e0d59', 0.8);
		$sgwindow_colors_class->set_color($i, 2, '#0e0d59', 0.8);

			
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');

		
	//section menu 
		$section_id = 'menu_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('First Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);
		
		$i = 'menu1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4', 0.9);
		$sgwindow_colors_class->set_color($i, 1, '#f4f4f4', 0.9);
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4', 0.9);

		$i = 'menu1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		
		
		
		$i = 'menu1_top_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');

		
		$i = 'menu1_hover_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4', 0.9);
		$sgwindow_colors_class->set_color($i, 1, '#f4f4f4', 0.9);
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4', 0.9);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section third menu 
		$section_id = 'menu_3_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu3_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#0e0d59', 0.8);
		$sgwindow_colors_class->set_color($i, 1, '#0e0d59', 0.8);
		$sgwindow_colors_class->set_color($i, 2, '#0e0d59', 0.8);
		
		$i = 'menu3_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');		

		$i = 'menu3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');
		
		$i = 'menu3_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.6);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.6);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f46a38');
		$sgwindow_colors_class->set_color($i, 1, '#f46a38');
		$sgwindow_colors_class->set_color($i, 2, '#f46a38');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 1, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#b2b2b2', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#b2b2b2', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#b2b2b2', 0.5);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 1);
		$sgwindow_colors_class->set_color($i, 1, '#112233', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.6);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.6);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.6);	
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');	
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 1, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 2, '#5e5e5e');
		
		$i = 'sidebar1_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.6);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.6);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.6);	
		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 1, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 2, '#5e5e5e');
		
		$i = 'sidebar4_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');	
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#666666');
		$sgwindow_colors_class->set_color($i, 1, '#666666');
		$sgwindow_colors_class->set_color($i, 2, '#666666');

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar3_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);		
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5b5b5b');
		$sgwindow_colors_class->set_color($i, 1, '#5b5b5b');
		$sgwindow_colors_class->set_color($i, 2, '#5b5b5b');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cecece', 0.6);
		$sgwindow_colors_class->set_color($i, 1, '#cecece', 0.6);
		$sgwindow_colors_class->set_color($i, 2, '#cecece', 0.6);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'column_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 0);
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 9);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#060a3f');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#060a3f');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#dbdbdb', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 0);
		
	} elseif ( 'SGDouble' == SGWINDOWCHILD ) {
	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
	
		$i = 'site_name_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.7);
		$sgwindow_colors_class->set_color($i, 1, '#1d5e1c', 0.7);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.7);

			
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');

		
	//section menu 
		$section_id = 'menu_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('First Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);
		
		$i = 'menu1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.7);
		$sgwindow_colors_class->set_color($i, 1, '#1d5e1c', 0.7);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);

		$i = 'menu1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		
		
		
		$i = 'menu1_top_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');

		
		$i = 'menu1_hover_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.9);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.9);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4');
		$sgwindow_colors_class->set_color($i, 1, '#b7ba2a');
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');		

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section third menu 
		$section_id = 'menu_3_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu3_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.8);
		$sgwindow_colors_class->set_color($i, 1, '#1d5e1c', 0.8);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.8);
		
		$i = 'menu3_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ea5a35');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');		
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');		

		$i = 'menu3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#13297a');
		$sgwindow_colors_class->set_color($i, 1, '#13297a');
		$sgwindow_colors_class->set_color($i, 2, '#13297a');
		
		$i = 'menu3_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#e2e2e2', 0);
		$sgwindow_colors_class->set_color($i, 1, '#e2e2e2', 0);
		$sgwindow_colors_class->set_color($i, 2, '#e2e2e2', 0);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#f46a38');
		$sgwindow_colors_class->set_color($i, 1, '#f46a38');
		$sgwindow_colors_class->set_color($i, 2, '#f46a38');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 1, '#d1d1d1');
		$sgwindow_colors_class->set_color($i, 2, '#d1d1d1');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be', 0.9);
		$sgwindow_colors_class->set_color($i, 1, '#1e73be', 0.9);
		$sgwindow_colors_class->set_color($i, 2, '#1e73be', 0.9);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#112233', 1);
		$sgwindow_colors_class->set_color($i, 1, '#112233', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#112233', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#e8e8e8', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#e8e8e8', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');	
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#3d3d3d');
		$sgwindow_colors_class->set_color($i, 1, '#3d3d3d');
		$sgwindow_colors_class->set_color($i, 2, '#3d3d3d');
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#eaeaea', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#eaeaea', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');		
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');		

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#828282');
		$sgwindow_colors_class->set_color($i, 1, '#828282');
		$sgwindow_colors_class->set_color($i, 2, '#828282');

		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#081535', 0.8);	
		$sgwindow_colors_class->set_color($i, 1, '#1d5e1c', 0.8);	
		$sgwindow_colors_class->set_color($i, 2, '#081535', 0.8);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar3_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#eaeaea', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#eaeaea', 1);
		$sgwindow_colors_class->set_color($i, 2, '#eaeaea', 1);		
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');	
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5b5b5b');
		$sgwindow_colors_class->set_color($i, 1, '#5b5b5b');
		$sgwindow_colors_class->set_color($i, 2, '#5b5b5b');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cecece', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cecece', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cecece', 0);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.5);
		
		$i = 'column_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#00000');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
		
	} elseif( 'SGLayout' == SGWINDOWCHILD ) {
	
		sgwindow_pro_sg_layout_colors();
		
	}
	elseif( 'SGDiamond' == SGWINDOWCHILD ) {
	
		sgwindow_pro_sg_diamond_colors();
		
	}

}
 /**
 * Add custom styles to the header.
 *
 * @since SG Window 1.0.0
*/
function sgwindow_pro_hook_css_colors() {

	global $sgwindow_colors_class;
	$colors = $sgwindow_colors_class;
?>
	<style type="text/css"> 	
	
	.boxed-site .site {
		width: 94%;
	}

	/* Top Menu */

		.sg-site-header-1 {
			background: <?php echo esc_attr($colors->get_color('site_name_back')); ?>;
		}		
		
		.head-wrapper {
			background: <?php echo esc_attr($colors->get_color('site_name_back_2')); ?>;
		}
	
		.top-1-navigation ul {
			background-color: <?php echo esc_attr($colors->get_color('menu1_hover_back')); ?>;
		}

		.top-1-navigation .horisontal-navigation li a {
			color: <?php echo esc_attr($colors->get_color('menu1_hover')); ?>;
		}	

		.top-1-navigation {
			background-color: <?php echo esc_attr($colors->get_color('menu1_color')); ?>;
		}

		.top-1-navigation .horisontal-navigation li ul {
			background-color: <?php echo esc_attr($colors->get_color('menu1_hover_back')); ?>;
		}

		.top-1-navigation .horisontal-navigation li ul li a {
			color: <?php echo esc_attr($colors->get_color('menu1_hover')); ?>;
		}

		.top-1-navigation .horisontal-navigation li ul .current-menu-ancestor > a,
		.top-1-navigation .horisontal-navigation li ul .current_page_ancestor > a {
			background-color: <?php echo esc_attr($colors->get_color('menu1_hover')); ?>;
			color: <?php echo esc_attr($colors->get_color('menu1_hover_back')); ?>;
		}	
		
		
		/* Second Top Menu */
		
		.top-navigation ul {
			background-color: <?php echo esc_attr($colors->get_color('menu2_hover_back')); ?>;
		}

		.top-navigation .horisontal-navigation li a {
			color: <?php echo esc_attr($colors->get_color('menu2_hover')); ?>;
		}			
		
		.top-navigation .horisontal-navigation li a:hover,
		.top-navigation .horisontal-navigation li ul li a:hover {
			color: <?php echo esc_attr( $colors->get_color( 'menu2_top_hover' ) ); ?>;
		}	
		
		.top-navigation {
			background-color: <?php echo esc_attr($colors->get_color('menu2_color')); ?>;
		}

		.top-navigation .horisontal-navigation li ul {
			background-color: <?php echo esc_attr($colors->get_color('menu2_hover_back')); ?>;
		}

		.top-navigation .horisontal-navigation li ul li a {
			color: <?php echo esc_attr($colors->get_color('menu2_hover')); ?>;
		}

		.top-navigation .horisontal-navigation li ul .current-menu-ancestor > a,
		.top-navigation .horisontal-navigation li ul .current_page_ancestor > a {
			background-color: <?php echo esc_attr($colors->get_color('menu2_hover')); ?>;
			color: <?php echo esc_attr($colors->get_color('menu2_hover_back')); ?> ;
		}
		
		/* Footer Menu */
		
		#footer-navigation ul {
			background-color: <?php echo esc_attr($colors->get_color('menu3_hover_back')); ?>;
		}

		#footer-navigation .horisontal-navigation li a {
			color: <?php echo esc_attr($colors->get_color('menu3_hover')); ?>;
		}	
		
		.site-info,
		#footer-navigation {
			background-color: <?php echo esc_attr($colors->get_color('menu3_color')); ?>;
			color: <?php echo esc_attr($colors->get_color('menu3_top_hover')); ?>;
		}

		.site-info,
		.site-info a,
		#footer-navigation .horisontal-navigation li a {
			color: <?php echo esc_attr($colors->get_color('menu3_link')); ?>;
		}	

		#footer-navigation .horisontal-navigation li ul {
			background-color: <?php echo esc_attr($colors->get_color('menu3_hover_back')); ?>;
		}

		#footer-navigation .horisontal-navigation li ul li a {
			color: <?php echo esc_attr($colors->get_color('menu3_hover')); ?>;
		}
		
		#footer-navigation .horisontal-navigation li ul .current-menu-item > a,
		#footer-navigation .horisontal-navigation li ul .current-menu-ancestor > a {
			background-color: <?php echo esc_attr($colors->get_color('menu3_hover')); ?>;
			color: <?php echo esc_attr($colors->get_color('menu3_hover_back')); ?>;
		}
		
		@media screen and (min-width: 680px) {
			.site .content {
				font-size: <?php echo esc_attr( sgwindow_get_theme_mod( 'body_font_size' ) ); ?>px;
			}
			
			.top-1-navigation ul {
				background-color: transparent;
			}

			.top-1-navigation .horisontal-navigation li a {
				color: <?php echo esc_attr($colors->get_color('menu1_link')); ?>;
			}
			
			.top-navigation ul {
				background-color: transparent;
			}

			.top-navigation .horisontal-navigation li a {
				color: <?php echo esc_attr($colors->get_color('menu2_link')); ?>;
			}
			
			#footer-navigation ul {
				background-color: transparent;
			}

			#footer-navigation .horisontal-navigation li a {
				color: <?php echo esc_attr($colors->get_color('menu3_link')); ?>;
			}
		}
		
		/* Widget Menu */
		
		.wide .widget.widget_nav_menu {
			background-color: <?php echo esc_attr( $colors->get_color( 'menu4_color' ) ); ?>;
		}

		.wide .widget.widget_nav_menu .menu li ul li a {
			color: <?php echo esc_attr( $colors->get_color( 'menu4_link' ) ); ?>;
		}
		
		.wide .widget.widget_nav_menu .menu > li a {
			color: <?php echo esc_attr( $colors->get_color( 'menu4_top' ) ); ?>;
		}

		.wide .widget.widget_nav_menu .menu > li ul li a:hover,
		.wide .widget.widget_nav_menu .menu > li a:hover {
			color: <?php echo esc_attr( $colors->get_color( 'menu4_hover' ) ); ?>;
		}
		
		.wide .widget.widget_nav_menu > div > .menu > li > a {
			border-bottom: 10px solid <?php echo esc_attr( $colors->get_color( 'menu4_border' ) ); ?>;
		}
		
		/* Top Sidebar */
		
		.sidebar-top-full .widget {
			background-color:<?php echo esc_attr($colors->get_color('sidebar1_color')); ?>;
		}	
		
		th,
		td,
		.sidebar-top-full .widget ul li:before,
		.sidebar-top-full .widget {
			color: <?php echo esc_attr($colors->get_color('sidebar1_text')); ?>;
		}
		.sidebar-top-full .widget a {
			color: <?php echo esc_attr($colors->get_color('sidebar1_link')); ?>;
		}
		.sidebar-top-full .widget a:hover {
			color: <?php echo esc_attr($colors->get_color('sidebar1_hover')); ?>;
		}		
		.sidebar-top-full .widget .widgettitle,
		.sidebar-top-full .widget .widget-title {
			background: <?php echo esc_attr($colors->get_color('sidebar1_header_color')); ?>;
			color: <?php echo esc_attr($colors->get_color('sidebar1_header_text')); ?>;
		}
		
		/* Before Footer Sidebar */
		
		.sidebar-before-footer .widget {
			background-color:<?php echo esc_attr($colors->get_color('sidebar4_color')); ?>;
		}
		
		th,
		td,
		.sidebar-before-footer .widget ul li:before,
		.sidebar-before-footer .widget {
			color: <?php echo esc_attr($colors->get_color('sidebar4_text')); ?>;
		}
		
		.sidebar-before-footer a {
			color: <?php echo esc_attr($colors->get_color('sidebar4_link')); ?>;
		}
		
		.sidebar-before-footer a:hover {
			color: <?php echo esc_attr($colors->get_color('sidebar4_hover')); ?>;
		}
		
		.sidebar-before-footer .widget .widgettitle,
		.sidebar-before-footer .widget .widget-title {
			background: <?php echo esc_attr($colors->get_color('sidebar4_header_color')); ?>;
			color: <?php echo esc_attr($colors->get_color('sidebar4_header_text')); ?>;
		}
		
		/* Footer Sidebar */
		
		.sidebar-footer {
			background-color: <?php echo esc_attr($colors->get_color('sidebar2_color')); ?>;
		}
		
		td,
		.sidebar-footer .widgettitle,
		.sidebar-footer .widget-title,
		.sidebar-footer .widget {
			color: <?php echo esc_attr($colors->get_color('sidebar2_text')); ?>;
		}
		.sidebar-footer .widget a {
			color: <?php echo esc_attr($colors->get_color('sidebar2_link')); ?>;
		}
		th,
		.sidebar-footer .widget a:hover {
			color: <?php echo esc_attr($colors->get_color('sidebar2_hover')); ?>;
		}
		
		/* Column sidebar */

		.main-area {
			background-color:<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>;
		}
		
		td,
		#sidebar-1 .widget-area .column .widget,
		.column .widget {
			color: <?php echo esc_attr($colors->get_color('sidebar3_text')); ?>;
		}

		#sidebar-1 .widget-area .column .widget a,
		.wide .column .widget.widget_nav_menu .menu > li a,
		.wide .column .widget.widget_nav_menu .menu li ul li a,		
		.column a {
			color: <?php echo esc_attr($colors->get_color('sidebar3_link')); ?>;
		}
		
		th,
		#sidebar-1 .widget-area .column .widget a:hover,
		.wide .column .widget.widget_nav_menu .menu > li a:hover,
		.column a:hover {
			color: <?php echo esc_attr($colors->get_color('sidebar3_hover')); ?>;
		}
		
		#sidebar-1 .widget-area .column .widget .widgettitle,
		#sidebar-1 .widget-area .column .widget .widget-title,
		.column .widget .widgettitle,
		.column .widget .widget-title {
			background: <?php echo esc_attr($colors->get_color('column_header_color')); ?>;
			color: <?php echo esc_attr($colors->get_color('column_header_text')); ?>;
		}
		
		#sidebar-1 .widget-area .column .widget,
		.wide .column .widget.widget_nav_menu,
		.column .widget {
			background: <?php echo esc_attr($colors->get_color('column_widget_back')); ?>;
		}	

		.column .widget {
			border: 1px solid <?php echo esc_attr($colors->get_color('column_border')); ?>;
		}
		
		/* content */
		
		.woo-shop .woocommerce-result-count,
		.woo-shop .woocommerce-pagination,
		.woo-shop .page-title,
		.woo-shop .products > li,
		.flex .content-container,
		#woocommerce-wrapper,
		.header-wrapper,
		.content-search,
		.comments-area,
		.nav-link,
		.pagination.loop-pagination,
		.content-container,
		.nothing-found,
		.archive-header {
			background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
			color: <?php echo esc_attr($colors->get_color('content_text')); ?>;
		}
		
		.entry-date a:hover:before,
		.author.vcard a:hover:before,
		.edit-link a:hover:before,
		.tag a:hover:before,
		.content .project a:hover:before,
		.tags a:hover:before,
		.content .project-list a:hover:before,
		.category-list a:hover:before,
		.comments-link a:hover:before {
			text-shadow: 5px 1px 10px <?php echo esc_attr($colors->get_color('box_shadow')); ?>;
		}
		
		.woo-shop .woocommerce-breadcrumb a,
		.woo-shop .woocommerce-breadcrumb,
		.woo-shop .orderby {
			color: <?php echo esc_attr($colors->get_color('content_text')); ?>;
		}
		
		.project-list a:hover,
		.category-list a:hover,
		.tags a:hover {
			box-shadow: 5px 1px 10px <?php echo esc_attr($colors->get_color('box_shadow')); ?>;
		}
		
		.woo-shop .woocommerce-breadcrumb {
			border-bottom: 5px solid <?php echo esc_attr($colors->get_color('content_color')); ?>;
		}
		
			/* Sidebar Widget */
			
			#page .widget.sgwindow_side_bar > .widget-title,
			#page .widget.sgwindow_side_bar > .widgettitle {
				background-color:<?php echo esc_attr( $colors->get_color('layout_title') ); ?>;
				border: 1px solid <?php echo esc_attr($colors->get_color('layout_border')); ?>;
			}
			
			.widget.sgwindow_side_bar {
				background: <?php echo esc_attr( $colors->get_color('layout_color') ); ?>;
			}
			
			.my-sidebar-layout {
				background: <?php echo esc_attr( $colors->get_color('layout_content') ); ?>;
				border: 1px solid <?php echo esc_attr( $colors->get_color('layout_border') ); ?>;
			}
			
			.my-sidebar-layout .widget .entry-content,
			.my-sidebar-layout .widget h1,
			.my-sidebar-layout .widget h3,
			.my-sidebar-layout .widget h4,
			.my-sidebar-layout .widget h5,
			.my-sidebar-layout .widget h6,
			.my-sidebar-layout .widget {
				color:<?php echo esc_attr( $colors->get_color('layout_text') ); ?>;
			}
			
			.my-sidebar-layout .widget a,
			.my-sidebar-layout li a,
			.my-sidebar-layout .column a {
				color:<?php echo esc_attr( $colors->get_color('layout_link') ); ?>;
			}			
			
			#page .widget .my-sidebar-layout .widget .widget-title,
			#page .widget .my-sidebar-layout .widget .widgettitle {
				background-color:<?php echo esc_attr( $colors->get_color('layout_title') ); ?>;
				color:<?php echo esc_attr( $colors->get_color('layout_title_text') ); ?>;
			}

		
		<?php if (  defined ( 'SGWINDOWCHILD' ) && 'SGSimple' == SGWINDOWCHILD ) : ?>
			.header-wrap {
				background:<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>;
			}
		<?php endif; ?>
		
		<?php if (  defined ( 'SGWINDOWCHILD' ) && ( 'SGLayout' == SGWINDOWCHILD || 'SGDiamond' == SGWINDOWCHILD ) ) : ?>
			
			.nav-link,
			#page .comment-body,
			.comments-area,
			.nothing-found,
			.content-container {
				border: none;
			}
			
			.pagination.loop-pagination,
			.woo-shop .woocommerce-result-count,
			.woocommerce-pagination,
			.woo-shop .page-title,
			.blog .content-container,
			.archive .content-container,
			.search .content-container,
			.archive-header,
			.page .site-content,
			.single .site-content {
				background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
				border: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			<?php if (  defined ( 'SGWINDOWCHILD' ) && ( 'SGDiamond' == SGWINDOWCHILD ) ) : ?>
			
			.site-content {
				background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
				border: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			<?php endif; ?>
			
			#page .comment-body:before,
			#page .comment-body:after,
			#page .entry-meta:before {
				border-bottom: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
				border-top: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}		
			
			#page .sidebar-footer-wrap {
				border-top: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}

			#page .comment-body:after, 
			#page .comment-body:before {
				border-left: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}			
			
			#page .comment-body:before,
			#page .comment-body:after,
			#page .entry-meta:before {
				background: #<?php echo esc_attr( 'cccccc' == get_background_color() ? 'eeeeee' : get_background_color() ); ?>;
			}
			
			.wide > .widget-area > .widget {
				border-bottom: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
				border-top: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			.sidebar-top-full {
				border: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}

			.sidebar-before-footer {
				border-top: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}

			.single .content-container {
				background: none;
			}
			
			/* footer */
			.sidebar-footer-wrap {
				background-color: <?php echo esc_attr($colors->get_color('sidebar2_color_column')); ?>;
			}	
			
			#page .sidebar-footer .widgettitle:after,
			#page .sidebar-footer .widget-title:after,
			#page .sidebar-footer .widgettitle:before,
			#page .sidebar-footer .widget-title:before {
				background: <?php echo esc_attr($colors->get_color('sidebar2_color_column')); ?>;
				border-bottom: 1px solid <?php echo esc_attr($colors->get_color('sidebar2_color_column_border')); ?>;
				border-top: 1px solid <?php echo esc_attr($colors->get_color('sidebar2_color_column_border')); ?>;
			}

			.sidebar-footer {
				border: 1px solid <?php echo esc_attr($colors->get_color('sidebar2_color_column_border')); ?>;
			}			
			
			#page .sidebar-1,
			#page .sidebar-2 {
				background: <?php echo esc_attr($colors->get_color('sidebar32_back')); ?>;
				border: 1px solid <?php echo esc_attr($colors->get_color('column_border')); ?>;
			}
			
			<?php if (  defined ( 'SGWINDOWCHILD' ) && ( 'SGLayout' == SGWINDOWCHILD ) ) : ?>
			
			#page .column .widgettitle:after,
			#page .column .widget-title:after,
			#page .column .widgettitle:before,
			#page .column .widget-title:before {
				background: #<?php echo esc_attr( 'cccccc' == get_background_color() ? 'eeeeee' : get_background_color() ); ?>;
				border-bottom: 1px solid <?php echo esc_attr($colors->get_color('column_border')); ?>;
				border-top: 1px solid <?php echo esc_attr($colors->get_color('column_border')); ?>
			}
			
			<?php endif; ?>
			
			/* Sidebar Widget */
			
			#page .widget.sgwindow_side_bar > .widget-title,
			#page .widget.sgwindow_side_bar > .widgettitle {
				background-color:<?php echo esc_attr( $colors->get_color('layout_title') ); ?>;
				border: 1px solid <?php echo esc_attr($colors->get_color('layout_border')); ?>;
			}
			
			.widget.sgwindow_side_bar {
				background: <?php echo esc_attr( $colors->get_color('layout_color') ); ?>;
			}
			
			.my-sidebar-layout {
				background: <?php echo esc_attr( $colors->get_color('layout_content') ); ?>;
				border: 1px solid <?php echo esc_attr( $colors->get_color('layout_border') ); ?>;
			}
			
			.my-sidebar-layout .widget .entry-content,
			.my-sidebar-layout .widget h1,
			.my-sidebar-layout .widget h3,
			.my-sidebar-layout .widget h4,
			.my-sidebar-layout .widget h5,
			.my-sidebar-layout .widget h6,
			.my-sidebar-layout .widget {
				color:<?php echo esc_attr( $colors->get_color('layout_text') ); ?> !important;
			}
			
			.my-sidebar-layout .widget a,
			.my-sidebar-layout li a,
			.my-sidebar-layout .column a {
				color:<?php echo esc_attr( $colors->get_color('layout_link') ); ?> !important;
			}			
			
			#page .my-sidebar-layout .widget .widget-title,
			#page .my-sidebar-layout .widget .widgettitle {
				background-color:<?php echo esc_attr( $colors->get_color('layout_title') ); ?> !important;
				color:<?php echo esc_attr( $colors->get_color('layout_title_text') ); ?> !important;
			}
			
			
		<?php elseif (  defined ( 'SGWINDOWCHILD' ) && ( 'SGCircus' == SGWINDOWCHILD || 'SGSimple' == SGWINDOWCHILD ) ) : ?>

			.nav-link,
			.comment-body,
			.comments-area,
			.pagination.loop-pagination,
			.nothing-found,
			.content-container {
				border: none;
			}
			
			.woo-shop .woocommerce-result-count,
			.woocommerce-pagination,
			.woo-shop .page-title,
			.blog .content-container,
			.archive .content-container,
			.search .content-container,
			.archive-header,
			.page .site-content,
			.single .site-content {
				background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
				border: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			.sidebar-top-full {
				border: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}

			.sidebar-before-footer {
				border-top: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}

			.single .content-container {
				background: none;
			}
			
		<?php elseif (  defined ( 'SGWINDOWCHILD' ) && ( 'SGDouble' == SGWINDOWCHILD ) ) : ?>

			#page .entry-meta {
				border-top: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			#page .sidebar-1 .column .widget {

				background: -moz-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%, <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 30%, <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 41%, <?php echo esc_attr($colors->get_color('column_widget_back')); ?> 100%); /* FF3.6+ */
				background: -webkit-gradient(linear, left top, right top, color-stop(0%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>), color-stop(30%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>), color-stop(41%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>), color-stop(100%,<?php echo esc_attr($colors->get_color('column_widget_back')); ?>)); /* Chrome,Safari4+ */
				background: -webkit-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 30%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 41%, <?php echo esc_attr($colors->get_color('column_widget_back')); ?> 100%); /* Chrome10+,Safari5.1+ */
				background: -o-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?>,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 30%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>) 41%, <?php echo esc_attr($colors->get_color('column_widget_back')); ?> 100%); /* Opera 11.10+ */
				background: -ms-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 30%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>) 41%, <?php echo esc_attr($colors->get_color('column_widget_back')); ?> 100%); /* IE10+ */
				background: linear-gradient(to right,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 30%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>) 41%, <?php echo esc_attr($colors->get_color('column_widget_back')); ?> 100%); /* W3C */

				border-left: none;
				border-right: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				border-top: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				border-bottom: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				 
			}
			
			#page .sidebar-2 .column .widget {

				border-right: none;
				border-left: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				border-top: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				border-bottom: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;	
				
				background: -moz-linear-gradient(left,  <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 0%, <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 30%, <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0.22)); ?> 67%, <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0)); ?> 100%); /* FF3.6+ */
				background: -webkit-gradient(linear, left top, right top, color-stop(0%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?>), color-stop(30%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?>), color-stop(67%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0.22)); ?>), color-stop(100%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0)); ?>)); /* Chrome,Safari4+ */
				background: -webkit-linear-gradient(left,  <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 0%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 30%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0.22)); ?> 67%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0)); ?> 100%); /* Chrome10+,Safari5.1+ */
				background: -o-linear-gradient(left,  <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 0%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 30%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0.22)); ?> 67%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0)); ?> 100%); /* Opera 11.10+ */
				background: -ms-linear-gradient(left,  <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 0%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 30%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0.22)); ?> 67%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0)); ?> 100%); /* IE10+ */
				background: linear-gradient(to right,  <?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 0%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 1)); ?> 30%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0.22)); ?> 67%,<?php echo esc_attr(sgwindow_hex_to_rgba( $colors->get_color_val( 'column_widget_back' ), 0)); ?> 100%); /* W3C */

			}
			
			#page .right-sidebar .nav-link,
			#page .right-sidebar .comment-body,
			#page .right-sidebar .comments-area,
			#page .right-sidebar .pagination.loop-pagination,
			#page .right-sidebar .nothing-found,
			.single #page .right-sidebar .content-container,
			.archive #page .default.right-sidebar .content-container,
			.blog #page .default.right-sidebar .content-container,
			.search #page .default.right-sidebar .content-container,
			.page #page .right-sidebar .content-container {
			
				background: -moz-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%, <?php echo esc_attr($colors->get_color('content_color')); ?> 22%, <?php echo esc_attr($colors->get_color('content_color')); ?> 100%); /* FF3.6+ */
				background: -webkit-gradient(linear, left top, right top, color-stop(0%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>), color-stop(22%,<?php echo esc_attr($colors->get_color('content_color')); ?>), color-stop(100%,<?php echo esc_attr($colors->get_color('content_color')); ?>)); /* Chrome,Safari4+ */
				background: -webkit-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 22%,<?php echo esc_attr($colors->get_color('content_color')); ?> 100%); /* Chrome10+,Safari5.1+ */
				background: -o-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 22%,<?php echo esc_attr($colors->get_color('content_color')); ?> 100%); /* Opera 11.10+ */
				background: -ms-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 22%,<?php echo esc_attr($colors->get_color('content_color')); ?> 100%); /* IE10+ */
				background: linear-gradient(to right,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 22%,<?php echo esc_attr($colors->get_color('content_color')); ?> 100%); /* W3C */

			}			
			
			#page .left-sidebar .nav-link,
			#page .left-sidebar .comment-body,
			#page .left-sidebar .comments-area,
			#page .left-sidebar .pagination.loop-pagination,
			#page .left-sidebar .nothing-found,
			.single #page .left-sidebar .content-container,
			.archive #page .default.left-sidebar .content-container,
			.blog #page .default.left-sidebar .content-container,
			.search #page .default.left-sidebar .content-container,
			.page #page .left-sidebar .content-container {
			
				background: -moz-linear-gradient(left,  <?php echo esc_attr($colors->get_color('content_color')); ?> 0%, <?php echo esc_attr($colors->get_color('content_color')); ?> 78%, <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* FF3.6+ */
				background: -webkit-gradient(linear, left top, right top, color-stop(0%,<?php echo esc_attr($colors->get_color('content_color')); ?>), color-stop(78%,<?php echo esc_attr($colors->get_color('content_color')); ?>), color-stop(100%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>)); /* Chrome,Safari4+ */
				background: -webkit-linear-gradient(left,  <?php echo esc_attr($colors->get_color('content_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 78%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* Chrome10+,Safari5.1+ */
				background: -o-linear-gradient(left,  <?php echo esc_attr($colors->get_color('content_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 78%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* Opera 11.10+ */
				background: -ms-linear-gradient(left,  <?php echo esc_attr($colors->get_color('content_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 78%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* IE10+ */
				background: linear-gradient(to right,  <?php echo esc_attr($colors->get_color('content_color')); ?> 0%,<?php echo esc_attr($colors->get_color('content_color')); ?> 78%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* W3C */

			}						
			
			.single #page .no-sidebar .nav-link,
			.single #page .no-sidebar .comment-body,
			.single #page .no-sidebar .comments-area,
			.single #page .no-sidebar .pagination.loop-pagination,
			.single #page .no-sidebar .nothing-found,
			.single #page .no-sidebar .content-container,
			
			.page #page .no-sidebar .nav-link,
			.page #page .no-sidebar .comment-body,
			.page #page .no-sidebar .comments-area,
			.page #page .no-sidebar .pagination.loop-pagination,
			.page #page .no-sidebar .nothing-found,
			.page #page .no-sidebar .content-container,
			
			#page .no-sidebar.default .nav-link,
			#page .no-sidebar.default .comment-body,
			#page .no-sidebar.default .comments-area,
			#page .no-sidebar.default .pagination.loop-pagination,
			#page .no-sidebar.default .nothing-found,
			#page .no-sidebar.default .content-container {
			
				background: #fff /* Old browsers */
				background: -moz-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 2%, <?php echo esc_attr($colors->get_color('content_color')); ?> 10%, <?php echo esc_attr($colors->get_color('content_color')); ?> 10%, <?php echo esc_attr($colors->get_color('content_color')); ?> 90%, <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* FF3.6+ */
				background: -webkit-gradient(linear, left top, right top, color-stop(2%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>), color-stop(10%,<?php echo esc_attr($colors->get_color('content_color')); ?>), color-stop(10%,<?php echo esc_attr($colors->get_color('content_color')); ?>), color-stop(90%,<?php echo esc_attr($colors->get_color('content_color')); ?>), color-stop(100%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?>)); /* Chrome,Safari4+ */
				background: -webkit-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 2%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 90%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* Chrome10+,Safari5.1+ */
				background: -o-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 2%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 90%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* Opera 11.10+ */
				background: -ms-linear-gradient(left,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 2%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 90%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* IE10+ */
				background: linear-gradient(to right,  <?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 2%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 10%,<?php echo esc_attr($colors->get_color('content_color')); ?> 90%,<?php echo esc_attr($colors->get_color('sidebar3_color')); ?> 100%); /* W3C */
			
				border-right: none;
				border-left: none;
				border-top: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				border-bottom: 3px double <?php echo esc_attr($colors->get_color('column_border')); ?>;
				
				border-radius: 0;

			}

			#page .sidebar-footer .widget.sgwindow_page .content-container,
			#page .column .widget.sgwindow_page,
			#page .widget-area .column .widget-area .widget.sgwindow_page {
				border: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			#page .widget.sgwindow_page .transparent .content-container {
				background: transparent;
			}
			
			#page .column .widget.sgwindow_page .content-container,
			#page .sidebar-footer .widget .content-container {
				background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
			}

			.woo-shop .products li,
			.woo-shop .woocommerce-result-count,
			.woocommerce-pagination,
			.woo-shop .page-title,
			.nav-link,
			.comment-body,
			.comments-area,
			.pagination.loop-pagination,
			.archive-header,
			.nothing-found,
			.content-container {
				background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
				border: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			.right-sidebar .nav-link,
			.right-sidebar .comment-body,
			.right-sidebar .comments-area,
			.right-sidebar .pagination.loop-pagination,
			.right-sidebar .nothing-found {	
				border-left: none;
				border-right: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
				border-top: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
				border-bottom: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			.left-sidebar .nav-link,
			.left-sidebar .comment-body,
			.left-sidebar .comments-area,
			.left-sidebar .pagination.loop-pagination,
			.left-sidebar .nothing-found {	
				border-right: none;
				border-left: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
				border-top: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
				border-bottom: 3px double <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
			.woo-shop .woocommerce-result-count,
			.woocommerce-pagination,
			.woo-shop .page-title,
			.blog .content-container,
			.archive .content-container,
			.content-container,
			.archive-header {
				background: <?php echo esc_attr($colors->get_color('content_color')); ?>;
			}
			
			#page .image-wrapper {
				background-color: <?php echo esc_attr($colors->get_color('menu2_color')); ?>;
			}
			
			#page .sidebar-top-full {
				background: <?php echo esc_attr($colors->get_color('sidebar1_color')); ?>;
			}
			#page .sidebar-before-footer {
				background: <?php echo esc_attr($colors->get_color('sidebar4_color')); ?>;
			}
			
			#page .widget.sgwindow_page,
			#page .sidebar-2 .column .widget:before,
			#page .sidebar-1 .column .widget:before {
				background: <?php echo esc_attr($colors->get_color('sidebar3_color')); ?>;
			}
			
		
		<?php else : ?>
		
			.woo-shop .woocommerce-result-count,
			.woocommerce-pagination,
			.woo-shop .page-title,
			.nav-link,
			.comment-body,
			.comments-area,
			.pagination.loop-pagination,
			.archive-header,
			.nothing-found,
			.content-container {
				border: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
			}
			
		<?php endif; ?>
		
		
		.menu-top.position-fixed {
			box-shadow: 0 0 4px 4px <?php echo esc_attr($colors->get_color('content_border')); ?>;
		}
		
		.site-content .entry-title {
			border-bottom: 1px solid <?php echo esc_attr($colors->get_color('content_border')); ?>;
		}
		
		/* widget buttons */
		.widget.sgwindow_widget_button {
			background: <?php echo esc_attr($colors->get_color('buttons_color')); ?>;
		}
		
		.widget.sgwindow_widget_button .sgwindow-link {
			background: <?php echo esc_attr($colors->get_color('buttons_button')); ?>;
		}		
		
		.widget.sgwindow_widget_button a {
			color: <?php echo esc_attr($colors->get_color('buttons_link')); ?>;
		}
		.widget.sgwindow_widget_button a:hover {
			color: <?php echo esc_attr($colors->get_color('buttons_hover')); ?>;
		}
		.widget.sgwindow_widget_button .sgwindow-link {
			border-color: <?php echo esc_attr($colors->get_color('buttons_border')); ?>;
		}
		.widget.sgwindow_widget_button .sgwindow-link:hover {
			box-shadow: 0 0 4px 4px <?php echo esc_attr($colors->get_color('buttons_border')); ?>;
		}

	</style>
	<?php
}
add_action('wp_head', 'sgwindow_pro_hook_css_colors');

 /**
 * Add extra color options
 *
 * @since SG Window Pro 1.0.1
*/
function sgwindow_pro_sg_layout_colors() {

	$defaults = sgwindow_get_defaults();
	
	global $sgwindow_colors_class;
	
	if ( defined ( 'SGWINDOWCHILD' ) ) {
	 	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
		
		/* colors */
		
		$i = 'site_name_back_2';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.2);
		$sgwindow_colors_class->set_color($i, 1, '#81d742', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#25c1f9', 0.6);
		
	//section menu 
			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#31591b', 1);
		$sgwindow_colors_class->set_color($i, 2, '#251066', 1);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#81d742', 0.3);
		$sgwindow_colors_class->set_color($i, 1, '#81d742', 0.3);
		$sgwindow_colors_class->set_color($i, 2, '#81d742', 0.3);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#545454');
		$sgwindow_colors_class->set_color($i, 1, '#545454');
		$sgwindow_colors_class->set_color($i, 2, '#545454');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#131a38', 1);
		$sgwindow_colors_class->set_color($i, 1, '#131a38', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#131a38', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#a3adce');
		$sgwindow_colors_class->set_color($i, 1, '#a3adce');
		$sgwindow_colors_class->set_color($i, 2, '#a3adce');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');			
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 1, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 2, '#5e5e5e');
		
		$i = 'sidebar1_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);	

		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');	

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 1, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 2, '#5e5e5e');
		
		$i = 'sidebar4_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);
		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Columns Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#dddddd', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#31591b', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#251066', 1);			
		
		$i = 'sidebar2_color_column';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, false, 'refresh');

		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#e5e5e5', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#e5e5e5', 1);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');	
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#757575');
		$sgwindow_colors_class->set_color($i, 1, '#c6c6c6');
		$sgwindow_colors_class->set_color($i, 2, '#c6c6c6');
		
		$i = 'sidebar2_color_column_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);	

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar32_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');			
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 1, '#a71fdd');
		$sgwindow_colors_class->set_color($i, 2, '#a71fdd');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 1, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 2, '#aaaaaa');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#777777');		
		$sgwindow_colors_class->set_color($i, 1, '#777777');
		$sgwindow_colors_class->set_color($i, 2, '#777777');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'column_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Border', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#cccccc');
		$sgwindow_colors_class->set_color($i, 1, '#cccccc');
		$sgwindow_colors_class->set_color($i, 2, '#cccccc');
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#666666');		
		$sgwindow_colors_class->set_color($i, 1, '#666666');
		$sgwindow_colors_class->set_color($i, 2, '#666666');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);
		
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');
		
	//sidebar-widget
		$section_id = 'sidebar-widget';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Layout Builder', 'sgwindowpro'), __('Widget-sidebar colors', 'sgwindowpro'), $section_priority++);

		$i = 'layout_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);	
		$sgwindow_colors_class->set_color($i, 1, '#f7f7f7', 0);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);	
		
		$i = 'layout_content';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff7', 0.9);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);	
		
		$i = 'layout_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Border Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);	
		
		$i = 'layout_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');	
		
		$i = 'layout_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#666666');	
		$sgwindow_colors_class->set_color($i, 1, '#666666');	
		$sgwindow_colors_class->set_color($i, 2, '#666666');	
		
		$i = 'layout_title';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');	
		
		$i = 'layout_title_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Title Text', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	}
}

/**
 * Add extra color options
 *
 * @since SG Window Pro 1.0.1
*/
function sgwindow_pro_sg_diamond_colors() {

	$defaults = sgwindow_get_defaults();
	
	global $sgwindow_colors_class;
	
	if ( defined ( 'SGWINDOWCHILD' ) ) {
	 	
		$section_id = 'main_colors';
		$section_priority = 10;
		$p = 0;
		
		/* colors */
		
		$i = 'site_name_back_2';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Site Name and Description Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0.2);
		$sgwindow_colors_class->set_color($i, 1, '#81d742', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#25c1f9', 0.6);
		
	//section menu 
			
	//section second menu 
		$section_id = 'menu_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Second Top Menu', 'sgwindowpro'), __('Menu Colors', 'sgwindowpro'), $section_priority++);

		$i = 'menu2_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#31591b', 1);
		$sgwindow_colors_class->set_color($i, 2, '#251066', 1);

		
		$i = 'menu2_top_hover';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		
		$i = 'menu2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

		$i = 'menu2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text on Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'menu2_hover_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover Background', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');

	//section custom menu 
		$section_id = 'menu_4_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Menu', 'sgwindowpro'), __('Colors for the Widget Custom Menu in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'menu4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Menu', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#81d742', 0.3);
		$sgwindow_colors_class->set_color($i, 1, '#81d742', 0.3);
		$sgwindow_colors_class->set_color($i, 2, '#81d742', 0.3);

		$i = 'menu4_top';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Top Level Items', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#dd3333');
		$sgwindow_colors_class->set_color($i, 1, '#dd3333');
		$sgwindow_colors_class->set_color($i, 2, '#dd3333');
		
		$i = 'menu4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

		$i = 'menu4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
		$i = 'menu4_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#545454');
		$sgwindow_colors_class->set_color($i, 1, '#545454');
		$sgwindow_colors_class->set_color($i, 2, '#545454');

	//section buttons
		$section_id = 'buttons';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Widget Buttons', 'sgwindowpro'), __('Colors for the Widget Buttons in the top and before footer sidebars', 'sgwindowpro'), $section_priority++);

		$i = 'buttons_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);
		
		$i = 'buttons_button';
				
		$sgwindow_colors_class->add_color($i, $section_id, __('Button Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#131a38', 1);
		$sgwindow_colors_class->set_color($i, 1, '#131a38', 0.5);
		$sgwindow_colors_class->set_color($i, 2, '#131a38', 1);
		
		$i = 'buttons_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'buttons_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#a3adce');
		$sgwindow_colors_class->set_color($i, 1, '#a3adce');
		$sgwindow_colors_class->set_color($i, 2, '#a3adce');
		
		$i = 'buttons_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#1e73be');
		$sgwindow_colors_class->set_color($i, 1, '#1e73be');
		$sgwindow_colors_class->set_color($i, 2, '#1e73be');
		
	//top sidebar 
		$section_id = 'sidebar_1_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Top Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar1_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background color', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#f4f4f4', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4', 1);	
		
		$i = 'sidebar1_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');			
		
		$i = 'sidebar1_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar1_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 1, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 2, '#5e5e5e');
		
		$i = 'sidebar1_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
		
		$i = 'sidebar1_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	//before footer sidebar 
		$section_id = 'sidebar_4_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Before Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar4_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background', 'sgwindowpro'), $p+=2, true);
		$sgwindow_colors_class->set_color($i, 0, '#f4f4f4', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#f4f4f4', 1);
		$sgwindow_colors_class->set_color($i, 2, '#f4f4f4', 1);	

		$i = 'sidebar4_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');	

		$i = 'sidebar4_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar4_text';

		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 1, '#5e5e5e');
		$sgwindow_colors_class->set_color($i, 2, '#5e5e5e');
		
		$i = 'sidebar4_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 0);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0);
		
		$i = 'sidebar4_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
	//footer sidebar 
		$section_id = 'sidebar_2_colors';
		$p = 0;
		
		$sgwindow_colors_class->add_section($section_id, __('Footer Sidebar', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar2_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Columns Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#dddddd', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#31591b', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#251066', 1);			
		
		$i = 'sidebar2_color_column';

		$sgwindow_colors_class->add_color($i, $section_id, __('Sidebar Background Color', 'sgwindowpro'), $p++, false, 'refresh');

		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#e5e5e5', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#e5e5e5', 1);	
		
		$i = 'sidebar2_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');	
		
		$i = 'sidebar2_hover';

		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar2_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#c6c6c6');
		$sgwindow_colors_class->set_color($i, 2, '#c6c6c6');
		
		$i = 'sidebar2_color_column_border';

		$sgwindow_colors_class->add_color($i, $section_id, __('Border Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);	

	//columns
		$section_id = 'sidebar_3_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Columns', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'sidebar32_back';

		$sgwindow_colors_class->add_color($i, $section_id, __('Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);			
		
		$i = 'sidebar3_link';

		$sgwindow_colors_class->add_color($i, $section_id, __('Link', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');	
		
		$i = 'sidebar3_hover';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Hover', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'sidebar3_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 1, '#aaaaaa');
		$sgwindow_colors_class->set_color($i, 2, '#aaaaaa');
		
		$i = 'column_header_color';

		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 1);
		
		$i = 'column_header_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Title Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#000000');		
		$sgwindow_colors_class->set_color($i, 1, '#000000');
		$sgwindow_colors_class->set_color($i, 2, '#000000');
		
		$i = 'column_widget_back';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Widget Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');
						
	//content
		$section_id = 'content_colors';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Content', 'sgwindowpro'), __('Sidebar Colors', 'sgwindowpro'), $section_priority++);

		$i = 'content_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);	
		
		$i = 'content_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text', 'sgwindowpro'), $p++, false);
		$sgwindow_colors_class->set_color($i, 0, '#666666');		
		$sgwindow_colors_class->set_color($i, 1, '#666666');
		$sgwindow_colors_class->set_color($i, 2, '#666666');		
		
		$i = 'content_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Border', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 0);
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 0);
		
		$i = 'box_shadow';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Shadow color', 'sgwindowpro'), $p++, true, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 1, '#000000', '0.5');
		$sgwindow_colors_class->set_color($i, 2, '#000000', '0.5');
		
	//sidebar-widget
		$section_id = 'sidebar-widget';
		$p = 0;

		$sgwindow_colors_class->add_section($section_id, __('Layout Builder', 'sgwindowpro'), __('Widget-sidebar colors', 'sgwindowpro'), $section_priority++);

		$i = 'layout_color';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#e0e0e0', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#e0e0e0', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#e0e0e0', 1);	
		
		$i = 'layout_content';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Content Background Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff7', 0.9);	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff', 0.9);	
		
		$i = 'layout_border';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Border Color', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 1, '#cccccc', 1);	
		$sgwindow_colors_class->set_color($i, 2, '#cccccc', 1);	
		
		$i = 'layout_link';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Link Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');	
		
		$i = 'layout_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Text Color', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#666666');	
		$sgwindow_colors_class->set_color($i, 1, '#666666');	
		$sgwindow_colors_class->set_color($i, 2, '#666666');	
		
		$i = 'layout_title';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Title Background', 'sgwindowpro'), $p++, true);
		$sgwindow_colors_class->set_color($i, 0, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 1, '#ffffff');	
		$sgwindow_colors_class->set_color($i, 2, '#ffffff');	
		
		$i = 'layout_title_text';
		
		$sgwindow_colors_class->add_color($i, $section_id, __('Title Text', 'sgwindowpro'), $p++, false, 'refresh');
		$sgwindow_colors_class->set_color($i, 0, '#000000');	
		$sgwindow_colors_class->set_color($i, 1, '#000000');	
		$sgwindow_colors_class->set_color($i, 2, '#000000');

	}
}