<?php
/*
Plugin Name: SG Window Pro
Plugin URI: http://wpblogs.ru/themes/sg-window-pro/
Description: This is an extension for WordPress theme SG Window. Adds more options such as custom colors, custom layouts.
Author: WP Blogs
Version: 1.1
Author URI: http://wpblogs.ru/themes/
Text Domain: sgwindowpro

*/

define( 'SGWINDOW', 'Pro' );

function sg_window_pro_domain() {

	load_plugin_textdomain( 'sgwindowpro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

}
add_action( 'admin_init', 'sg_window_pro_domain' );

function sg_window_pro_init() {
	if ( ! function_exists ( 'sgwindow_get_theme_mod' ) )
		return;
		
	if ( defined( 'SGWINDOWCHILD' )
		&& 'SGGrid' != SGWINDOWCHILD 
		&& 'SGSimple' != SGWINDOWCHILD 
		&& 'SGCircus' != SGWINDOWCHILD 
		&& 'SGDouble' != SGWINDOWCHILD 
		&& 'SGLayout' != SGWINDOWCHILD 
		&& 'SGDiamond' != SGWINDOWCHILD 
		)
		return;	
	
	if ( ! class_exists ( 'sgwindow_Widget_Colors_Class' ) ) :

	//	include( plugin_dir_path( __FILE__ ) . 'inc/customize-widget-colors.php');
		
		/* custom colors */
	//	global $sgwindow_Widget_Colors_Class;
	//	$sgwindow_Widget_Colors_Class = new sgwindow_Widget_Colors_Class();

	endif;

	require ( plugin_dir_path( __FILE__ ) . 'inc/customize.php');
		
	require ( plugin_dir_path( __FILE__ ) . 'inc/customize-colors.php');
	
}
add_action( 'after_setup_theme', 'sg_window_pro_init' );